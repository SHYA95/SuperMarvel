//
//  ResonseResults.swift
//  SuperMarvel
//
//  Created by Shrouk Yasser on 17/11/2023.
//


import Foundation


typealias SeriesResults = (Result<MarvelResponse, ServerError>) -> Void
