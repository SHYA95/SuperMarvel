//
//  UrlPath.swift
//  SuperMarvel
//
//  Created by Shrouk Yasser on 17/11/2023.
//

enum UrlPath: String {
    
    // MARK: - Series
    case characters = "/series"
    
}
